# URL-Validator
A project to detect fraud/fake/phishing websites and warn you about them. Powered by machine learning.
